using OpenTK.Graphics.OpenGL4;
using StbImageSharp;

namespace Open_TK_Tut_1;

public static class StaticUtilities
{
    public static readonly string MainDirectory = Directory.GetParent(Directory.GetCurrentDirectory())!.Parent!.Parent + "\\";
    public static readonly string TextureDirectory = MainDirectory + "Textures\\";
    public static readonly string ShaderDirectory = MainDirectory + "Shaders\\";

    //This runs as soon as the project loads.
    static StaticUtilities()
    {
        StbImage.stbi_set_flip_vertically_on_load(1);
    }
    
    public static void CheckError(string stage)
    {
        ErrorCode errorCode = GL.GetError();
        if (errorCode != ErrorCode.NoError)
        {
            Console.WriteLine($"OpenGL Error ({stage}): {errorCode}");
        }
    }
    
    

}