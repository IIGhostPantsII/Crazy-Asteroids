using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace Open_TK_Tut_1;

public class Game : GameWindow
{

    //TASK: make the triangle lerp between colors
    // 2 pt: base code is functional
    // 2 pt: lerping between two colors
    // 4 pt: lerping between five or more colors
    // 2 pt: each color displays for exactly 3 seconds

    private float[] verticies =
    {
        -1, 1, 0, 0, 2, // Top Left
        -1, -1, 0, 0, 0, // Bottom Left
        1, -1, 0, 2, 0, // Bottom Right
        1, 1, 0, 2, 2 // Top Right
    };

    private uint[] indices =
    {
        0, 1, 2,
        0, 2, 3
    };
    

    private float x;

    private Shader shader;
    private Texture tex0;
    private Texture tex1;

    private GameObject A;
    private GameObject B;
    
    public static Matrix4 view;
    public static Matrix4 projection;

    public static Camera gameCam;
    private Vector2 previousMousePos;

    public Game(int width, int height, string title) : base(GameWindowSettings.Default,
        new NativeWindowSettings() { Title = title, Size = (width, height) })
    {
    }

    protected override void OnLoad()
    {
        base.OnLoad();

        GL.ClearColor(1, 0, 0, 0);

        previousMousePos = new Vector2(MouseState.X, MouseState.Y);
        CursorState = CursorState.Grabbed;

        //Enable blending
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);

        shader = new Shader("shader.vert", "shader.frag");
        tex0 = new Texture("container.jpg");
        tex1 = new Texture("Bender.png");
        
        gameCam = new Camera(Vector3.UnitZ * 3, (float)Size.X / Size.Y);
        A = new GameObject(verticies, indices, shader);
        StaticUtilities.CheckError("A");
        A.transform.Position += Vector3.UnitX * 3f;
        
        B = new GameObject(verticies, indices, shader);
        
        StaticUtilities.CheckError("B");

        
        shader.Use();

        tex0.Use(TextureUnit.Texture0);
        int id = shader.GetUniformLocation("tex0");
        GL.ProgramUniform1(shader.Handle, id, 0);
        
        tex1.Use(TextureUnit.Texture1);
        id = shader.GetUniformLocation("tex1");
        GL.ProgramUniform1(shader.Handle, id, 1);
        
    }

    protected override void OnUnload()
    {
        //Free GPU RAM
        GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
        
        GL.UseProgram(0);
        
        A.Dispose();
        B.Dispose();
        shader.Dispose();

        base.OnUnload();
    }

    protected override void OnResize(ResizeEventArgs e)
    {
        base.OnResize(e);
    }

    protected override void OnRenderFrame(FrameEventArgs args)
    {
        base.OnRenderFrame(args);
        //MUST BE FIRST
        GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

        view = gameCam.GetViewMatrix();
        projection = gameCam.GetProjectionMatrix();
        
        
        tex0.Use(TextureUnit.Texture0);
        tex1.Use(TextureUnit.Texture1);
        
        shader.Use();
        int getCpuColor = shader.GetUniformLocation("uniformColor");
        x = (x + 0.0001f) % 1;
        //Console.WriteLine(getCpuColor);
        
        GL.Uniform4(getCpuColor, new Color4(x, 0, 0, 1.0f));
        
        StaticUtilities.CheckError("B");
        
        A.Render();
        B.Render();


        
        //MUST BE LAST
        SwapBuffers();
    }

    private float n;
    protected override void OnUpdateFrame(FrameEventArgs args)
    {
        base.OnUpdateFrame(args);


        if (KeyboardState.IsKeyDown(Keys.Escape))
        {
            Close();
        }

        n += (float)args.Time;
        A.transform.Rotation = new Vector3(0,0,A.transform.Rotation.Z + (float)args.Time);
        A.transform.Scale = new Vector3(1, (float)Math.Sin(n) * 5, 1);


        const float cameraSpeed = 1.5f;
        const float sensitivity = 0.2f;

        if (KeyboardState.IsKeyDown(Keys.W))
        {
            gameCam.Position += gameCam.Forward * cameraSpeed * (float)args.Time; // Forward
        }

        if (KeyboardState.IsKeyDown(Keys.S))
        {
            gameCam.Position -= gameCam.Forward * cameraSpeed * (float)args.Time; // Backwards
        }

        if (KeyboardState.IsKeyDown(Keys.A))
        {
            gameCam.Position -= gameCam.Right * cameraSpeed * (float)args.Time; // Left
        }

        if (KeyboardState.IsKeyDown(Keys.D))
        {
            gameCam.Position += gameCam.Right * cameraSpeed * (float)args.Time; // Right
        }

        if (KeyboardState.IsKeyDown(Keys.Space))
        {
            gameCam.Position += gameCam.Up * cameraSpeed * (float)args.Time; // Up
        }

        if (KeyboardState.IsKeyDown(Keys.LeftShift))
        {
            gameCam.Position -= gameCam.Up * cameraSpeed * (float)args.Time; // Down
        }

        // Get the mouse state

        // Calculate the offset of the mouse position
        var deltaX = MouseState.X - previousMousePos.X;
        var deltaY = MouseState.Y - previousMousePos.Y;
        previousMousePos = new Vector2(MouseState.X, MouseState.Y);

        // Apply the camera pitch and yaw (we clamp the pitch in the camera class)
        gameCam.Yaw += deltaX * sensitivity;
        gameCam.Pitch -= deltaY * sensitivity; // Reversed since y-coordinates range from bottom to top

    }
    

protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
        base.OnMouseWheel(e);

        gameCam.Fov -= e.OffsetY;
    }
    
    
   
}