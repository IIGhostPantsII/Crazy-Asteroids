using Assimp;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.GraphicsLibraryFramework;
using NAudio.Wave;
using System;
using Quaternion = OpenTK.Mathematics.Quaternion;

namespace Open_TK_Tut_1;

public class Game : GameWindow
{
    private float x;

    private Shader shader;
    private Shader litShader;
    private Shader mushShader;
    private Shader texShader;
    private Shader terrainShader;
    
    
    private Texture tex0;
    private Texture tex1;
    private Texture tex2;
    private Texture skyboxTex;
    private Texture terrainTex;
    private Texture groundTex;
    private Texture moonTex;
    private Texture asteroidTex;
    private Texture titleTex;
    private Texture pauseTex;
    private Texture endTex;

    public static readonly List<GameObject> LitObjects = new();
    public static readonly List<GameObject> UnLitObjects = new();
    public static readonly List<PointLight> Lights = new();
    
    public static Matrix4 view;
    public static Matrix4 projection;

    public static Camera gameCam;
    private Vector3 cameraPosition;
    private Vector2 previousMousePos;
    
    private bool isMouseLeftClicked = false;
    private double litObject2RenderedTimestamp = 0;
    private double timeStamp = 0;
    
    List<Texture> explosionFrames = new List<Texture>();

    private bool StartTimer;
    private bool theBool;
    private bool collidedWithAnyObject = false;
    private bool debugMode;
    
    private WaveOutEvent waveOut;
    private WaveOutEvent waveOutScream;
    
    private float overallTime = 0f;
    private float asteroidPositionUpdateTime = 0f;
    private float asteroidPositionUpdateInterval = 5f;
    private float deltaX;
    private float deltaY;
    private bool firstAsteroidSpawned = false;

    private int startNumber = 0;

    private bool MENUS = true;
    private bool audioPlaying = false;

    private bool keyPressed = false;

    private Vector3 originalCamRot;
    private float originalCamYaw;
    private float originalCamPitch;

    private bool GAMEOVER = false;
    private bool CLOSEGAME = false;
    
    private readonly string[] PointLightDefinition =
    {
        "pointLights[",
        "INDEX",
        "]."
    };

    public Game(int width, int height, string title) : base(GameWindowSettings.Default,
        new NativeWindowSettings() { Title = title, Size = (width, height) })
    {
    }

    protected override void OnLoad()
    {
        base.OnLoad();

        GL.ClearColor(0, 0, 0, 0);

        // Set the display mode to fullscreen
        WindowState = WindowState.Fullscreen;
        WindowBorder = WindowBorder.Hidden;
        
        //Audio Things
        waveOut = new WaveOutEvent();
        var audioFilePath = Path.Combine(StaticUtilities.MusicDirectory+"Title_Theme.mp3");
        var audioFile = new AudioFileReader(audioFilePath);
        waveOut.Init(audioFile);
        waveOut.Play();
        
        for (int i = 1; i < 18; i++)
        {
            Texture frameTexture = new Texture($"explode\\{i}.png");
            explosionFrames.Add(frameTexture);
        }
        
        timeStamp = GLFW.GetTime();

        previousMousePos = new Vector2(MouseState.X, MouseState.Y);
        CursorState = CursorState.Grabbed;

        //Enable blending
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);

        GL.Enable(EnableCap.CullFace);
        GL.Enable(EnableCap.DepthTest);
        
        shader = new Shader("shader.vert", "shader.frag");
        litShader = new Shader("shader.vert", "Lit_shader.frag");
        mushShader = new Shader("MyShader\\David.vert", "MyShader\\David.frag");
        texShader = new Shader("skybox.vert", "skybox.frag");
        terrainShader = new Shader("terrain.vert", "terrain.frag");

        tex0 = new Texture("metal.jpg");
        tex1 = new Texture("Bender.png");
        tex2 = new Texture("Grain.png");
        skyboxTex = new Texture("skybox.jpg");
        terrainTex = new Texture("rock.jpg");
        groundTex = new Texture("grass.jpg");
        moonTex = new Texture("moon.jpg");
        asteroidTex = new Texture("asteroid.jpg");
        titleTex = new Texture("Titlescreen2.png");
        pauseTex = new Texture("Pause.png");
        endTex = new Texture("End.png");
        
        gameCam = new Camera(Vector3.UnitZ * 3, (float)Size.X / Size.Y);
        originalCamRot = gameCam.Position;
        originalCamPitch = gameCam.Pitch;
        originalCamYaw = gameCam.Yaw;
        AssimpContext importer = new AssimpContext();
        PostProcessSteps postProcessSteps = PostProcessSteps.Triangulate | PostProcessSteps.FlipUVs;
        Scene scene = importer.ImportFile(StaticUtilities.ObjectDirectory + "plane.fbx", postProcessSteps);
        UnLitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), terrainShader));
        UnLitObjects[0].transform.Position = new Vector3(-2, 0.5f, 3);
        UnLitObjects[0].transform.Rotation = new Vector3(0, -MathHelper.PiOver2, MathHelper.PiOver2 * 2);
        UnLitObjects[0].transform.Scale = new Vector3(2, 2, 1);
        
        UnLitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), terrainShader));
        UnLitObjects[1].transform.Position = new Vector3(2, 0.5f, 3);
        UnLitObjects[1].transform.Rotation = new Vector3(0, -MathHelper.PiOver2, 0);
        UnLitObjects[1].transform.Scale = new Vector3(2, 2, 1);
        
        //Animation One
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, new Shader("MyShader\\Animation.vert", "MyShader\\Animation.frag")));
        UnLitObjects[2].transform.Position = new Vector3(0, 10000000, 0);
        
        UnLitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), terrainShader));
        UnLitObjects[3].transform.Position = new Vector3(1, 0.5f, 6.5f);
        UnLitObjects[3].transform.Rotation = new Vector3(0, -180, MathHelper.PiOver2 * 2);
        UnLitObjects[3].transform.Scale = new Vector3(2, 2, 1);
        
        UnLitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), terrainShader));
        UnLitObjects[4].transform.Position = new Vector3(-1, 0.5f, 6.5f);
        UnLitObjects[4].transform.Rotation = new Vector3(0, -180, 0);
        UnLitObjects[4].transform.Scale = new Vector3(2, 2, 1);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[5].transform.Position = new Vector3(0, -1.4f, 0);
        UnLitObjects[5].transform.Scale = new Vector3(8, 5, 1);
        UnLitObjects[5].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[6].transform.Position = new Vector3(50, 0, 0);
        UnLitObjects[6].transform.Scale = new Vector3(75, 75, 1);
        UnLitObjects[6].transform.Rotation = new Vector3(0, -MathHelper.PiOver2, 0);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[7].transform.Position = new Vector3(0, 0, 50);
        UnLitObjects[7].transform.Scale = new Vector3(75, 75, 1);
        UnLitObjects[7].transform.Rotation = new Vector3(0, -MathHelper.Pi, 0);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[8].transform.Position = new Vector3(-50, 0, 0);
        UnLitObjects[8].transform.Scale = new Vector3(75, 75, 1);
        UnLitObjects[8].transform.Rotation = new Vector3(0, MathHelper.PiOver2, 0);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[9].transform.Position = new Vector3(0, -50, 0);
        UnLitObjects[9].transform.Scale = new Vector3(75, 75, 1);
        UnLitObjects[9].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[10].transform.Position = new Vector3(0, 50, 0);
        UnLitObjects[10].transform.Scale = new Vector3(75, 75, 1);
        UnLitObjects[10].transform.Rotation = new Vector3(MathHelper.PiOver2, 0, 0);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[11].transform.Position = new Vector3(0, 0, -50);
        UnLitObjects[11].transform.Scale = new Vector3(75, 75, 1);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[12].transform.Position = new Vector3(-35, 30, -45);
        UnLitObjects[12].transform.Scale = new Vector3(8, 8, 1);
        UnLitObjects[12].transform.Rotation = new Vector3(0, 0, 0);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[13].transform.Position = new Vector3(0, 0, 2.2f);
        UnLitObjects[13].transform.Scale = new Vector3(1.536f, 0.864f, 1);
        UnLitObjects[13].transform.Rotation = new Vector3(0, 0, 0);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[14].transform.Position = new Vector3(0, 0, 20000.2f);
        UnLitObjects[14].transform.Scale = new Vector3(1.536f, 0.864f, 1);
        UnLitObjects[14].transform.Rotation = new Vector3(0, 0, 0);
        
        UnLitObjects.Add(new GameObject(StaticUtilities.QuadVertices, StaticUtilities.QuadIndices, texShader));
        UnLitObjects[15].transform.Position = new Vector3(0, 0, -50.2f);
        UnLitObjects[15].transform.Scale = new Vector3(1.536f, 8.064f, 1);
        UnLitObjects[15].transform.Rotation = new Vector3(0, 0, 0);
        
        
        LitObjects.Add(new GameObject(StaticUtilities.BoxVertices, StaticUtilities.BoxIndices, litShader));
        LitObjects[0].transform.Position = new Vector3(0, 100, 0);
        
        scene = importer.ImportFile(StaticUtilities.ObjectDirectory + "Asteroid.fbx", postProcessSteps);
        LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), litShader));
        LitObjects[1].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        LitObjects[1].transform.Position = new Vector3(-MathHelper.PiOver2, 4, -400);
        
        //StaticUtilities.CheckError("B");
        
        scene = importer.ImportFile(StaticUtilities.ObjectDirectory + "plane.fbx", postProcessSteps);
        LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), new Shader("WaveTutorial\\Waves.vert", "WaveTutorial\\Waves.frag")));
        LitObjects[2].transform.Position = new Vector3(0, -1.75f, 6.5f);
        LitObjects[2].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        LitObjects[2].transform.Scale = new Vector3(2.6f, 2.6f, 1);
        
        scene = importer.ImportFile(StaticUtilities.ObjectDirectory + "Mushroom.fbx", postProcessSteps);
        LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), mushShader));
        LitObjects[3].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        LitObjects[3].transform.Position = new Vector3(10000, -0.25f, 0);
        
        scene = importer.ImportFile(StaticUtilities.ObjectDirectory + "Bullet.fbx", postProcessSteps);
        LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), texShader));
        LitObjects[4].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        LitObjects[4].transform.Position = new Vector3(-MathHelper.PiOver2, 400, 0);
        LitObjects[4].transform.Scale = new Vector3(0.25f, 0.25f, 0.25f);
        
        scene = importer.ImportFile(StaticUtilities.ObjectDirectory + "Asteroid.fbx", postProcessSteps);
        LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), texShader));
        LitObjects[5].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        LitObjects[5].transform.Position = new Vector3(5, 4, -300000000000000);
        LitObjects[5].transform.Scale = new Vector3(0.5f, 0.5f, 0.5f);
        
        LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), texShader));
        LitObjects[6].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        LitObjects[6].transform.Position = new Vector3(5, 4, -300000000000000);
        LitObjects[6].transform.Scale = new Vector3(0.5f, 0.5f, 0.5f);
        
        LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), texShader));
        LitObjects[7].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        LitObjects[7].transform.Position = new Vector3(5, 4, -300000000000000);
        LitObjects[7].transform.Scale = new Vector3(0.5f, 0.5f, 0.5f);
        
        LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), texShader));
        LitObjects[8].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        LitObjects[8].transform.Position = new Vector3(5, 4, -300000000000000);
        LitObjects[8].transform.Scale = new Vector3(0.5f, 0.5f, 0.5f);
        
        LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), texShader));
        LitObjects[9].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
        LitObjects[9].transform.Position = new Vector3(5, 4, -300000000000000);
        LitObjects[9].transform.Scale = new Vector3(0.5f, 0.5f, 0.5f);

        Lights.Add(new PointLight(new Vector3(1,0,0), 1));
        Lights[0].Transform.Position = Vector3.UnitX + Vector3.UnitY * 6 + Vector3.UnitZ * 3;
        Lights.Add(new PointLight(new Vector3(0,1,0), 2));
        Lights[1].Transform.Position = Vector3.UnitX + Vector3.UnitY * -6 + Vector3.UnitZ * 3;
        Lights.Add(new PointLight(new Vector3(0, 0, 1), 100)); // Red laser light
        Lights[2].Transform.Position = LitObjects[4].transform.Position; // Set laser's position
        //light.Transform.Position
        //StaticUtilities.CheckError("C");

        
        
        
        shader.Use();

        tex0.Use(TextureUnit.Texture0);
        int id = shader.GetUniformLocation("tex0");
        GL.ProgramUniform1(shader.Handle, id, 0);
        
        tex1.Use(TextureUnit.Texture1);
        id = shader.GetUniformLocation("tex1");
        GL.ProgramUniform1(shader.Handle, id, 1);

        litShader.Use(); 
        tex0.Use(TextureUnit.Texture0);
        id = litShader.GetUniformLocation("tex0");
        GL.ProgramUniform1(litShader.Handle, id, 0);
        
        tex1.Use(TextureUnit.Texture1);
        id = litShader.GetUniformLocation("tex1");
        GL.ProgramUniform1(litShader.Handle, id, 1);
        
        mushShader.Use();

        tex2.Use(TextureUnit.Texture0);
        id = mushShader.GetUniformLocation("tex2");
        GL.ProgramUniform1(mushShader.Handle, id, 0);
        
        UnLitObjects[2].MyShader.Use();
        
        for (int i = 0; i < explosionFrames.Count; i++)
        {
            explosionFrames[i].Use(TextureUnit.Texture0 + i);
            id = UnLitObjects[2].MyShader.GetUniformLocation($"textures[{i}]");
            GL.ProgramUniform1(UnLitObjects[2].MyShader.Handle, id, i);
        }

        texShader.Use();
            
        skyboxTex.Use(TextureUnit.Texture0);
        id = texShader.GetUniformLocation("skyboxTex");
        GL.ProgramUniform1(texShader.Handle, id, 0);
        
        groundTex.Use(TextureUnit.Texture0);
        GL.ProgramUniform1(texShader.Handle, id, 0);
        
        moonTex.Use(TextureUnit.Texture0);
        GL.ProgramUniform1(texShader.Handle, id, 0);
        
        asteroidTex.Use(TextureUnit.Texture0);
        GL.ProgramUniform1(texShader.Handle, id, 0);
        
        titleTex.Use(TextureUnit.Texture0);
        GL.ProgramUniform1(texShader.Handle, id, 0);
        
        pauseTex.Use(TextureUnit.Texture0);
        GL.ProgramUniform1(texShader.Handle, id, 0);
        
        endTex.Use(TextureUnit.Texture0);
        GL.ProgramUniform1(texShader.Handle, id, 0);

        terrainShader.Use();
        id = texShader.GetUniformLocation("terrainTex");
        GL.ProgramUniform1(texShader.Handle, id, 0);
    }

    protected override void OnUnload()
    {
        //Free GPU RAM
        GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
        
        GL.UseProgram(0);
        
        for (int i = UnLitObjects.Count-1; i >= 0; --i)
        {
            UnLitObjects[i].Dispose();
        }
        for (int i = LitObjects.Count-1; i >= 0; --i)
        {
            LitObjects[i].Dispose();
        }

        shader.Dispose();
        
        mushShader.Dispose();
        
        UnLitObjects[2].MyShader.Dispose();
        
        texShader.Dispose();
        
        terrainShader.Dispose();
        
        // Stop playing the sound and release resources
        waveOut.Stop();
        waveOut.Dispose();

        base.OnUnload();
    }

    protected override void OnResize(ResizeEventArgs e)
    {
        base.OnResize(e);
    }

    protected override void OnRenderFrame(FrameEventArgs args)
    {
        base.OnRenderFrame(args);
        //MUST BE FIRST
        GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

        view = gameCam.GetViewMatrix();
        projection = gameCam.GetProjectionMatrix();
        cameraPosition = gameCam.Position;
        
        
        tex0.Use(TextureUnit.Texture0);
        tex1.Use(TextureUnit.Texture1);
        
        shader.Use();
        int getCpuColor = shader.GetUniformLocation("uniformColor");
        x += (float)args.Time;
        //x = (x + 0.0001f) % 1;
        //Console.WriteLine(getCpuColor);
        GL.Uniform4(getCpuColor, new Color4(x, 0, 0, 1.0f));
        
        UnLitObjects[1].MyShader.Use();
        int idx = UnLitObjects[1].MyShader.GetUniformLocation("time");
        GL.Uniform1(idx, x);
        
        UnLitObjects[2].MyShader.Use();
        for (int i = 0; i < explosionFrames.Count; i++)
        {
            explosionFrames[i].Use(TextureUnit.Texture0 + i);
            int id = UnLitObjects[2].MyShader.GetUniformLocation($"textures[{i}]");
            GL.ProgramUniform1(UnLitObjects[2].MyShader.Handle, id, i);
        }
        idx = UnLitObjects[2].MyShader.GetUniformLocation("time");
        GL.Uniform1(idx, x);
        
        UnLitObjects[2].Render();
        
        tex0.Use(TextureUnit.Texture0);
        tex1.Use(TextureUnit.Texture1);

        if (!MENUS)
        {
            // Check for collision with LitObjects[4]
            if (isMouseLeftClicked)
            {
                collidedWithAnyObject = false;

                if (!collidedWithAnyObject)
                {
                    // Set the model matrix for LitObjects[4] in front of the camera
                    LitObjects[4].transform.Position = gameCam.Position + gameCam.Forward * 1;
                    tex0.Use(TextureUnit.Texture0);
                    LitObjects[4].Render();
                    MoveAsteroid(5, 1, args);
                }
            }
        }

        // Check for collision with every game object except LitObjects[4]
        foreach (GameObject gameObject in UnLitObjects.Concat(LitObjects.Where(obj => obj != LitObjects[4])))
        {
            float distanceToObject = Vector3.Distance(gameObject.transform.Position, LitObjects[4].transform.Position);
            float collisionThresholdFour = 1.2f; // Adjust as needed

            if (distanceToObject < collisionThresholdFour)
            {
                // Collision detected with gameObject
                LitObjects[4].transform.Position = new Vector3(0, 100000, 0);
                for (int i = 5; i < 10; i++)
                {
                    if (!isMouseLeftClicked)
                    {
                        if (gameObject == LitObjects[i])
                        {
                            Console.WriteLine("Hit!");
                            gameObject.transform.Position = new Vector3(0, 10000000, -100);
                        }
                    }
                }
                collidedWithAnyObject = true;
                break; // Exit the loop if there is a collision with any object
            }
        }
        
        // Check if 2 seconds have passed and destroy LitObjects[4]
        if (litObject2RenderedTimestamp > 0 && GLFW.GetTime() - litObject2RenderedTimestamp > 2)
        {
            LitObjects[4].transform.Position = new Vector3(0, 10000000000, 0);
            litObject2RenderedTimestamp = 0; // Reset the timestamp
        }
        
        LitObjects[2].MyShader.Use();
        idx = LitObjects[2].MyShader.GetUniformLocation("time");
        //x += (float)args.Time;
        GL.Uniform1(idx, x);
        
        LitObjects[3].MyShader.Use();
        idx = LitObjects[3].MyShader.GetUniformLocation("time");
        GL.Uniform1(idx, x);
        int cameraPosLocation = LitObjects[3].MyShader.GetUniformLocation("cameraPosition");
        GL.Uniform3(cameraPosLocation, gameCam.Position);
        
        // Check for collision and print to console
        float distanceToMushroom = Vector3.Distance(LitObjects[3].transform.Position, gameCam.Position);
        float collisionThreshold = 1.05f; // Adjust as needed
        
        //StaticUtilities.CheckError("B");

        int counter = 0;
        int unCounter = 0;
        
        foreach (GameObject unlit in UnLitObjects)
        {
            unCounter++;
            if (unCounter > 6 && unCounter != 3 && unCounter < 13)
            {
                
            }
            else if(unCounter == 6)
            {
                groundTex.Use(TextureUnit.Texture0);
                unlit.Render();
            }
            else if (unCounter == 13)
            {
                moonTex.Use(TextureUnit.Texture0);
                unlit.Render();
            }
            else if (unCounter == 14)
            {
                titleTex.Use(TextureUnit.Texture0);
                unlit.Render();
            }
            else if (unCounter == 15)
            {
                pauseTex.Use(TextureUnit.Texture0);
                unlit.Render();
            }
            else if (unCounter == 16)
            {
                endTex.Use(TextureUnit.Texture0);
                unlit.Render();
            }
            else
            {
                terrainTex.Use(TextureUnit.Texture0);
                unlit.Render();
            }
        }
        foreach (GameObject lit in LitObjects)
        {
            counter++;
            int id;
            lit.MyShader.Use();
            for (int i = 0; i < Lights.Count; i++)
            {
                PointLight currentLight = Lights[i];
                PointLightDefinition[1] = i.ToString();
                string merged = string.Concat(PointLightDefinition);
                
                id = lit.MyShader.GetUniformLocation(merged + "lightColor");
                GL.Uniform3(id, currentLight.Color);
                id = lit.MyShader.GetUniformLocation(merged + "lightPosition");
                GL.Uniform3(id, currentLight.Transform.Position);
                id = lit.MyShader.GetUniformLocation(merged + "lightIntensity");
                GL.Uniform1(id, currentLight.Intensity);
            }
            id = lit.MyShader.GetUniformLocation("numPointLights");
            GL.Uniform1(id, Lights.Count);
            if (counter > 5 && counter < 11)
            {
                asteroidTex.Use(TextureUnit.Texture0);
            }
            else
            {
                tex0.Use(TextureUnit.Texture0);
            }
            lit.Render();
        }
        
        if (timeStamp > 0 && GLFW.GetTime() - timeStamp > 15 && !theBool || distanceToMushroom < collisionThreshold && !theBool)
        {
            LitObjects[3].transform.Position = new Vector3(0, 10000000000, 0);
            UnLitObjects[2].transform.Position = new Vector3(0, 10000, 0);
            UnLitObjects[2].Render();
            if(!StartTimer)
            {
                StartTimer = true;
            }
            timeStamp = 0; // Reset the timestamp
        }
        
        if (StartTimer && !theBool)
        {
            timeStamp += (float)args.Time;
            // Check if 1 second has passed since StartTimer became true
            if (timeStamp > 0.75f)
            {
                UnLitObjects[2].transform.Position = new Vector3(0, 10000000000, 0);
                theBool = true;
            }
        }
        
        skyboxTex.Use(TextureUnit.Texture0);
        UnLitObjects[6].Render();
        UnLitObjects[7].Render();
        UnLitObjects[8].Render();
        UnLitObjects[9].Render();
        UnLitObjects[10].Render();
        UnLitObjects[11].Render();
        
        //MUST BE LAST
        SwapBuffers();
    }

    private float n;
    protected override void OnUpdateFrame(FrameEventArgs args)
    {
        base.OnUpdateFrame(args);

        if (KeyboardState.IsKeyDown(Keys.Escape))
        {
            Vector3 lookAtDirection = gameCam.Position - UnLitObjects[14].transform.Position;
            float yaw = (float)Math.Atan2(lookAtDirection.X, lookAtDirection.Z);
            float pitch = (float)Math.Atan2(lookAtDirection.Y, Math.Sqrt(lookAtDirection.X * lookAtDirection.X + lookAtDirection.Z * lookAtDirection.Z));
            UnLitObjects[14].transform.Position = gameCam.Position + gameCam.Forward * 0.8f;
            UnLitObjects[14].transform.Rotation = new Vector3(-pitch, yaw, 0f);
            MENUS = true;
            keyPressed = false;
        }

        if (MENUS)
        {
            if (KeyboardState.IsKeyDown(Keys.T))
            {
                Vector3 lookAtDirection = gameCam.Position - UnLitObjects[13].transform.Position;
                float yaw = (float)Math.Atan2(lookAtDirection.X, lookAtDirection.Z);
                float pitch = (float)Math.Atan2(lookAtDirection.Y, Math.Sqrt(lookAtDirection.X * lookAtDirection.X + lookAtDirection.Z * lookAtDirection.Z));
                UnLitObjects[13].transform.Position = gameCam.Position + gameCam.Forward * 0.8f;
                UnLitObjects[13].transform.Rotation = new Vector3(-pitch, yaw, 0f);
                waveOut.Stop();
                waveOut = new WaveOutEvent();
                var audioFilePath = Path.Combine(StaticUtilities.MusicDirectory+"Title_Theme.mp3");
                var audioFile = new AudioFileReader(audioFilePath);
                waveOut.Init(audioFile);
                waveOut.Play();
            }
        }

        if (KeyboardState.IsKeyDown(Keys.Enter))
        {
            if (!keyPressed)
            {
                // This block will execute only once when the Enter key is pressed.
                // Perform your action here.
                MENUS = false;
                keyPressed = true;
                UnLitObjects[13].transform.Position = new Vector3(100, 100, 100);
                UnLitObjects[14].transform.Position = new Vector3(100, 100, 100);
                waveOut.Stop();
                waveOut = new WaveOutEvent();
                var audioFilePath = Path.Combine(StaticUtilities.MusicDirectory+"A_Powerful_Enemy_Emerges_Boss_Battle.mp3");
                var audioFile = new AudioFileReader(audioFilePath);
                waveOut.Init(audioFile);
                waveOut.Play();
            }
        }
        
        Vector3 direction = gameCam.Forward;
        float speed = 50.0f;
        
        n += (float)args.Time;

        Lights[0].Transform.Position = Vector3.UnitY * MathF.Sin(n) * 5 + Vector3.UnitZ * 5;
        Lights[0].Transform.Position = Quaternion.FromAxisAngle(Vector3.UnitY, n) * Lights[0].Transform.Position;
        
        
        const float cameraSpeed = 10.5f;
        const float sensitivity = 0.2f;
        
        ///*

        if (!MENUS)
        {
            if (debugMode)
            {
                if (KeyboardState.IsKeyDown(Keys.W))
                {
                    gameCam.Position += gameCam.Forward * cameraSpeed * (float)args.Time; // Forward
                }

                if (KeyboardState.IsKeyDown(Keys.S))
                {
                    gameCam.Position -= gameCam.Forward * cameraSpeed * (float)args.Time; // Backwards
                }

                if (KeyboardState.IsKeyDown(Keys.A))
                {
                    gameCam.Position -= gameCam.Right * cameraSpeed * (float)args.Time; // Left
                }

                if (KeyboardState.IsKeyDown(Keys.D))
                {
                    gameCam.Position += gameCam.Right * cameraSpeed * (float)args.Time; // Right
                }

                if (KeyboardState.IsKeyDown(Keys.Space))
                {
                    gameCam.Position += gameCam.Up * cameraSpeed * (float)args.Time; // Up
                }

                if (KeyboardState.IsKeyDown(Keys.LeftShift))
                {
                    gameCam.Position -= gameCam.Up * cameraSpeed * (float)args.Time; // Down
                }
            }
        }

        //*/
        
        if (KeyboardState.IsKeyDown(Keys.CapsLock))
        {
            debugMode = true;
        }
        else
        {
            debugMode = false;
        }

        
        // Check if LitObjects[4] still exists in the list
        if (LitObjects.Count > 4)
        {
            //Laser Things
            if (MouseState.IsButtonDown(MouseButton.Left))
            {
                isMouseLeftClicked = true;
            }
            else
            {
                isMouseLeftClicked = false;
            }

            LitObjects[4].transform.Position += direction * speed * (float)args.Time;
            
        }
        
        
        if (LitObjects.Count <= 2)
        {
            // Re-add the object to LitObjects
            AssimpContext importer = new AssimpContext();
            PostProcessSteps postProcessSteps = PostProcessSteps.Triangulate | PostProcessSteps.FlipUVs;
            Scene scene = importer.ImportFile(StaticUtilities.ObjectDirectory + "Bullet.fbx", postProcessSteps);
            LitObjects.Add(new GameObject(scene.Meshes[0].MergeMeshData(), scene.Meshes[0].GetUnsignedIndices(), litShader));
            LitObjects[4].transform.Rotation = new Vector3(-MathHelper.PiOver2, 0, 0);
            LitObjects[4].transform.Position = new Vector3(-MathHelper.PiOver2, 400, 0);
        }

        if (GAMEOVER)
        {
            overallTime += (float)args.Time;
            UnLitObjects[15].transform.Position = new Vector3(0, ((overallTime - 80) * 0.1f) - 6.5f, 2.15f);
            if ((overallTime - 80) > 108f)
            {
                //(overallTime - 120) > 105
                MENUS = false;
                CLOSEGAME = true;
                audioPlaying = false;
            }
        }

        if (!MENUS)
        {
            asteroidPositionUpdateTime += (float)args.Time;
            overallTime += (float)args.Time;
            if (overallTime > 80 && !CLOSEGAME)
            {
                gameCam.Position = originalCamRot;
                gameCam.Pitch = originalCamPitch;
                gameCam.Yaw = originalCamYaw;
                MENUS = true;
                GAMEOVER = true;
                waveOut.Stop();
                waveOut = new WaveOutEvent();
                var audioFilePath = Path.Combine(StaticUtilities.MusicDirectory+"Credits.mp3");
                var audioFile = new AudioFileReader(audioFilePath);
                waveOut.Init(audioFile);
                waveOut.Play();
                for (int i = 5; i < 10; i++)
                {
                    LitObjects[i].transform.Position = new Vector3(20, 10, -15);
                }
            }
            if (asteroidPositionUpdateTime >= asteroidPositionUpdateInterval)
            {
            
                Random random = new Random();
                asteroidPositionUpdateInterval = (float)random.NextDouble() * 2 + 1;
            
                // Call the method to update asteroid positions
                PositionAsteroid(startNumber + 5, -51);
                if (overallTime > 14)
                {
                    asteroidPositionUpdateInterval = (float)random.NextDouble() * 1.25f + 1;
                }
            
                if (overallTime > 29)
                {
                    asteroidPositionUpdateInterval = (float)random.NextDouble() * 1 + 0.5f;
                }
            
                if (overallTime > 44)
                {
                    asteroidPositionUpdateInterval = (float)random.NextDouble() * 1 + 0.25f;
                }
            
                if (overallTime > 59)
                {
                    asteroidPositionUpdateInterval = (float)random.NextDouble() * 0.5f + 0.25f;
                }

                // Reset the timer
                asteroidPositionUpdateTime = 0f;
            
                startNumber = (startNumber + 1) % 5;
            }
            
            for (int i = 5; i < 10; i++)
            {
                MoveAsteroid(i, 12 + (overallTime * 0.275f), args);
                waveOutScream = new WaveOutEvent();
                if (LitObjects[i].transform.Position.Z > gameCam.Position.Z - 4.75f && !audioPlaying)
                {
                    waveOutScream.Stop();
                    var audioFilePath = Path.Combine(StaticUtilities.SoundDirectory+"Funny_Ahh_Scream.wav");
                    var audioFile = new AudioFileReader(audioFilePath);
                    waveOutScream.Init(audioFile);
                    waveOutScream.Play();
                    audioPlaying = true;
                }
                
                if (LitObjects[i].transform.Position.Z > gameCam.Position.Z - 0.75f)
                {
                    //Lose
                    if (!debugMode)
                    {
                        Close();   
                    }
                }
            }

            // Get the mouse state

            // Calculate the offset of the mouse position
            deltaX = MouseState.X - previousMousePos.X;
            deltaY = MouseState.Y - previousMousePos.Y;
        }
        else
        {
            deltaX = 0f;
            deltaY = 0f;    
        }
        
        // Compute the direction from the object to the camera
        Vector3 directionToCamera = Vector3.Normalize(gameCam.Position - UnLitObjects[12].transform.Position);

        // Calculate the rotation angle based on the direction
        float rotationAngle = (float)Math.Atan2(directionToCamera.X, directionToCamera.Z);

        // Set the rotation for the object
        UnLitObjects[12].transform.Rotation = new Vector3(0, rotationAngle, 0);

        
        previousMousePos = new Vector2(MouseState.X, MouseState.Y);

        // Apply the camera pitch and yaw (we clamp the pitch in the camera class)
        gameCam.Yaw += deltaX * sensitivity;
        gameCam.Pitch -= deltaY * sensitivity; // Reversed since y-coordinates range from bottom to top

    }
    
    public void PositionAsteroid(int litObjectIndex, float zPos)
    {
        if (litObjectIndex >= 0 && litObjectIndex < LitObjects.Count)
        {
            // Get a random position within a certain range
            Random random = new Random();
            float randomX = (float)random.NextDouble() * 75 - 35; // Adjust the range as needed
            float randomY = (float)random.NextDouble() * 35 + 5;

            // Set the random position
            LitObjects[litObjectIndex].transform.Position = new Vector3(randomX, randomY, zPos);
        }
        else
        {
            Console.WriteLine("Invalid LitObject index");
        }
    }
    
    public void MoveAsteroid(int litObjectIndex, float moveSpeed, FrameEventArgs args)
    {
        if (litObjectIndex >= 0 && litObjectIndex < LitObjects.Count)
        {
            // Calculate the direction towards the gameCam position
            Vector3 direction = (gameCam.Position - LitObjects[litObjectIndex].transform.Position).Normalized();

            // Set the velocity based on the direction and moveSpeed
            LitObjects[litObjectIndex].transform.Position += direction * moveSpeed * (float)args.Time;
            LitObjects[litObjectIndex].transform.Rotation += new Vector3((float)args.Time, -(float)args.Time, (float)args.Time);
        }
        else
        {
            Console.WriteLine("Invalid LitObject index");
        }
    }
   
}