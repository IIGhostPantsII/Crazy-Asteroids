namespace Open_TK_Tut_1;

public class Quad
{
    
}